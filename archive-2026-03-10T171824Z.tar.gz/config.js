/**
 * Saxia Botz Configuration
 * Author: Kasan
 */

const fs = require('fs')
const chalk = require('chalk')

// ===== PAYMENT & LAYANAN ===== //
global.cash = 'cashify_a880b731e8d106c0f0ce8b4a8885ae9d92d57babd2d252d1eba0d4e0e693667b'
global.qris_id = 'f480f37b-1e13-4647-800e-fbd89a15b0da'
global.rumahotp = 'otp_BlrWaiQuiGGInZCB'
global.shopee = {
  apikey: '63f2624a48fee0176761802342e8c0564469c46f76ab6fbd41cb096a56ddae22'
}
global.btzpay = {
  apikey: '2654ebf859c36df043c2a398d96f6f4669a13617b05547b3255b806438541940'
}

// ===== OWNER & ROLE ===== //
global.owner = ['6287767510608']
global.mods = ['6287767510608']
global.prems = ['6287767510608']

global.nameowner = 'Sn'
global.numberowner = '6287767510608'
global.mail = 'support@saxiabotz.web.id'

// ===== SOCIAL ===== //
global.gc = '' // isi link grup kalau ada
global.instagram = 'https://instagram.com/shanv.konv'

// ===== BOT INFO ===== //
global.ruangotp = '787d59c7-86f0-4716-9d0e-9eeecc7d7eb8'
global.wm = '© Saxia Botz'
global.packname = 'Dibuat Oleh'
global.author = '© Saxia.js'

// ===== MESSAGE ===== //
global.wait = '_*Tunggu sedang diproses...*_'
global.eror = '_*Server Error*_'
global.stiker_wait = '*⫹⫺ Stiker sedang dibuat...*'

// ===== SYSTEM ===== //
global.gpt5 = 'xKDXYEf9auOCCqZf0RpKrS_cj8nYO3nvUIYeYaxc'
global.maxwarn = 2 // maksimal peringatan (number)
global.antiporn = true

// ===== API BETABOTZ (WAJIB DIISI) ===== //
global.lann = 'Kasan.7'
global.aksesKey = '' // isi kalau sudah register

global.APIs = {
  lann: 'https://api.betabotz.eu.org'
}

global.APIKeys = {
  'https://api.betabotz.eu.org': global.lann
}

// ===== AUTO RELOAD CONFIG ===== //
let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js' detected"))
  delete require.cache[file]
  require(file)
})