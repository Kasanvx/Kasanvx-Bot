const axios = require('axios')

global.btzPending ||= {}

let handler = async (m, { conn, args }) => {

  if (!args[0])
    return m.reply('Format:\n.btzpay 10000')

  let amount = parseInt(args[0])
  if (isNaN(amount) || amount < 1)
    return m.reply('Minimal Rp 1')

  if (!global.shopee?.apikey)
    return m.reply('API Key ShopeePay belum diset.')

  if (global.btzPending[m.sender])
    return m.reply('❌ Masih ada transaksi pending.')

  try {

    await m.reply('⏳ Membuat QRIS ShopeePay...')

    const { data } = await axios.post(
      'https://web.btzpay.my.id/api/qris/create',
      {
        apikey: global.shopee.apikey,
        amount,
        paymentMethod: 'qrisshopeepay', // ⬅ WAJIB
        timeout: 900000,
        notes: `Order by ${m.sender}`,
        metadata: { sender: m.sender }
      },
      { timeout: 15000 }
    )

    if (!data.success)
      return m.reply('❌ Gagal membuat transaksi')

    let trx = data.data

    let caption = `
🛍 *QRIS SHOPEEPAY*

🧾 ID: ${trx.transactionId}
💰 Amount: Rp${trx.amount.toLocaleString()}
💸 Fee: Rp${trx.fee.toLocaleString()}
🧮 Total: Rp${trx.totalAmount.toLocaleString()}

⏳ Expired:
${new Date(trx.expiredAt).toLocaleString('id-ID')}

🔗 *Link Pembayaran:*
${trx.paymentUrl}

Status: ${trx.status.toUpperCase()}
`.trim()

    let msg = await conn.sendMessage(m.chat, {
      image: { url: trx.qrisImage || trx.paymentUrl },
      caption
    }, { quoted: m })

    global.btzPending[m.sender] = {
      id: trx.transactionId,
      key: trx.accessKey,
      msgId: msg.key.id,
      chat: m.chat
    }

    startPolling(conn, m.sender)

  } catch (err) {
    console.log('CREATE ERROR:', err.response?.data || err.message)
    m.reply('❌ Gagal membuat transaksi')
  }
}

handler.command = /^btzpay$/i
handler.tags = ['payment']
handler.help = ['btzpay 10000']

module.exports = handler


// ===============================
// POLLING
// ===============================

function startPolling(conn, sender) {

  let interval = setInterval(async () => {

    let trx = global.btzPending[sender]
    if (!trx) return clearInterval(interval)

    try {

      const { data } = await axios.get(
        `https://web.btzpay.my.id/api/qris/transaction/${trx.id}`,
        { params: { key: trx.key } }
      )

      if (!data.success) return

      let status = data.data.status

      if (status === 'sukses') {

        await conn.sendMessage(trx.chat, {
          text: `✅ *PEMBAYARAN BERHASIL*\n\n🧾 ${trx.id}`
        })

        await deleteQR(conn, trx.chat, trx.msgId)
        delete global.btzPending[sender]
        clearInterval(interval)
      }

      if (['expired', 'cancel', 'gagal'].includes(status)) {

        await conn.sendMessage(trx.chat, {
          text: `❌ Transaksi ${status.toUpperCase()}\n🧾 ${trx.id}`
        })

        await deleteQR(conn, trx.chat, trx.msgId)
        delete global.btzPending[sender]
        clearInterval(interval)
      }

    } catch (err) {
      console.log('POLLING ERROR:', err.message)
    }

  }, 5000)
}


// ===============================
// DELETE QR
// ===============================

async function deleteQR(conn, chat, msgId) {
  try {
    await conn.sendMessage(chat, {
      delete: {
        remoteJid: chat,
        fromMe: true,
        id: msgId
      }
    })
  } catch {}
}