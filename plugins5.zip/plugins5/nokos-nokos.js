/**
 * NOKOS PRO CLEAN - RumahOTP V2
 * Termurah ≥ 3000 + Flag + Stock + Fee 30
 */

const axios = require('axios')

global.nokos ||= {}
global.nokosMenu ||= {}

const API = 'https://www.rumahotp.com/api'
const OTP_TIMEOUT = 80000
const FEE = 30
const MIN_PRICE = 3000

/* ======================= */

function getFlagEmoji(iso) {
  return iso
    .toUpperCase()
    .replace(/./g, char =>
      String.fromCodePoint(127397 + char.charCodeAt())
    )
}

async function getServices() {
  const { data } = await axios.get(`${API}/v2/services`, {
    headers: { 'x-apikey': global.api }
  })
  return data
}

async function getCountries(service_id) {
  const { data } = await axios.get(`${API}/v2/countries`, {
    params: { service_id },
    headers: { 'x-apikey': global.api }
  })
  return data
}

async function buyNumber(number_id, provider_id) {
  const { data } = await axios.get(`${API}/v2/orders`, {
    params: {
      number_id,
      provider_id,
      operator_id: 1
    },
    headers: { 'x-apikey': global.api }
  })
  return data
}

async function checkStatus(order_id) {
  const { data } = await axios.get(`${API}/v1/orders/get_status`, {
    params: { order_id },
    headers: { 'x-apikey': global.api }
  })
  return data
}

async function cancelOrder(order_id) {
  return axios.get(`${API}/v1/orders/set_status`, {
    params: { order_id, status: 'cancel' },
    headers: { 'x-apikey': global.api }
  })
}

/* ======================= */

let handler = async (m, { conn, args, usedPrefix }) => {

  if (!global.api)
    return m.reply('API key belum diset.')

  let user = db.data.users[m.sender] || (db.data.users[m.sender] = {})

  /* ===== STEP 1: LIST SERVICE ===== */
  if (!args[0]) {

    await m.reply('⏳ tunggu bentar ya kak...')

    let services = await getServices()
    if (!services.success)
      return m.reply('Gagal ambil layanan.')

    let list = services.data.slice(0, 20)
      .map(v => `➤ ${v.service_code}. ${v.service_name}`)
      .join('\n')

    return m.reply(
`╭───〔 *DAFTAR APLIKASI* 〕
│
│ Ketik:
│ ${usedPrefix}nokos <id>
│
├────────────────
${list}
╰────────────────`
    )
  }

  /* ===== STEP 2: LIST NEGARA TERMURAH ≥ 3000 ===== */

  await m.reply('⏳ tunggu bentar ya kak...')

  let service_id = args[0]
  let countries = await getCountries(service_id)

  if (!countries.success)
    return m.reply('Service tidak valid.')

  let available = countries.data
    .filter(v => v.stock_total > 0 && v.pricelist.length > 0)
    .map(v => ({
      ...v,
      basePrice: v.pricelist[0].price,
      finalPrice: v.pricelist[0].price + FEE
    }))
    .filter(v => v.finalPrice >= MIN_PRICE)

  if (!available.length)
    return m.reply('Tidak ada negara dengan harga minimal Rp3.000.')

  available.sort((a, b) => a.finalPrice - b.finalPrice)
  available = available.slice(0, 20)

  global.nokosMenu[m.sender] = {
    service_id,
    countries: available
  }

  let listNegara = available.map((v, i) => {
    let flag = getFlagEmoji(v.iso_code)
    return `${i + 1}. ${flag} ${v.name}
   💰 Rp${v.finalPrice.toLocaleString()}
   📦 Stock: ${v.stock_total}`
  }).join('\n\n')

  return m.reply(
`╭───〔 *NEGARA TERMURAH (≥ 3RB)* 〕
│
│ Reply angka 1 - ${available.length}
│
├────────────────
${listNegara}
╰────────────────`
  )
}

handler.command = /^nokos$/i
handler.tags = ['nokos']
handler.help = ['nokos']

module.exports = handler

/* =======================
   HANDLE REPLY ANGKA
======================= */

module.exports.before = async function (m, { conn }) {

  if (!global.nokosMenu[m.sender]) return
  if (!/^\d+$/.test(m.text)) return

  let menu = global.nokosMenu[m.sender]
  let index = parseInt(m.text) - 1

  if (!menu.countries[index]) return

  let user = db.data.users[m.sender] || (db.data.users[m.sender] = {})

  let country = menu.countries[index]
  let finalPrice = country.finalPrice

  if ((user.saldo || 0) < finalPrice) {
    delete global.nokosMenu[m.sender]
    return conn.reply(m.chat,
`❌ Saldo tidak cukup

💰 Harga : Rp${finalPrice.toLocaleString()}
💳 Saldo : Rp${(user.saldo || 0).toLocaleString()}

Silakan deposit ya kak.`,
    m)
  }

  await conn.reply(m.chat, '⏳ tunggu bentar ya kak...', m)

  let order = await buyNumber(
    country.number_id,
    country.pricelist[0].provider_id
  )

  if (!order.success) {
    delete global.nokosMenu[m.sender]
    return conn.reply(m.chat, 'Gagal membeli nomor.', m)
  }

  user.saldo -= finalPrice

  let d = order.data

  global.nokos[m.sender] = {
    order_id: d.order_id,
    chat: m.chat
  }

  delete global.nokosMenu[m.sender]

  await conn.reply(m.chat,
`╭───〔 *NOMOR BERHASIL DIBELI* 〕
│ 📱 ${d.phone_number}
│ 🌍 ${d.country}
│ 💰 Rp${finalPrice.toLocaleString()}
│ ⏳ Menunggu OTP...
╰────────────────`,
  m)

  startOtpCheck(conn, m.sender)
}

/* =======================
   AUTO OTP CHECK
======================= */

function startOtpCheck(conn, sender) {

  let trx = global.nokos[sender]
  if (!trx) return

  let start = Date.now()

  let interval = setInterval(async () => {

    let status = await checkStatus(trx.order_id)
    if (!status.success) return

    if (status.data.status === 'completed') {

      await conn.sendMessage(trx.chat, {
        text: `🎉 *OTP DITERIMA*

📱 ${status.data.phone_number}
🔐 OTP: ${status.data.otp_code}`
      })

      delete global.nokos[sender]
      clearInterval(interval)
    }

    if (Date.now() - start > OTP_TIMEOUT) {

      await cancelOrder(trx.order_id)

      await conn.sendMessage(trx.chat, {
        text: `❌ OTP tidak masuk dalam 1 menit 20 detik
Order otomatis dibatalkan.`
      })

      delete global.nokos[sender]
      clearInterval(interval)
    }

  }, 7000)
}