const axios=require('axios')
const BASE='https://api.ruangotp.site/api/v1'

let handler=async(m,{text})=>{
  if(!text)return m.reply('.cekdeposit DEP-xxxx')

  let res=await axios.get(
    `${BASE}/deposit/cekstatus?deposit_id=${text}`,
    {headers:{'x-user-id':global.ruangotp}}
  )

  let status=res.data.data.status
  if(status=='paid'){
    let depo=db.data.deposit[text]
    if(depo&&depo.status=='pending'){
      db.data.users[depo.sender].saldo+=depo.amount
      depo.status='paid'
      return m.reply('✅ Deposit berhasil & saldo masuk')
    }
  }
  m.reply('Status: '+status)
}

handler.help=['cekdeposit']
handler.tags=['nokos']
handler.command=/^cekdeposit$/i

module.exports=handler