let handler = async (m, { conn }) => {

  let user = db.data.users[m.sender] || (db.data.users[m.sender] = {})

  let saldo = user.saldo || 0

  m.reply(`💳 *CEK SALDO*

👤 User: @${m.sender.split('@')[0]}
💰 Saldo: Rp${saldo.toLocaleString()}`,
  null,
  { mentions: [m.sender] })

}

handler.help = ['ceksaldo']
handler.tags = ['nokos']
handler.command = /^(saldo|ceksaldo)$/i

module.exports = handler