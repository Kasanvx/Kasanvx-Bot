const axios = require('axios')

const API = 'https://www.rumahotp.com/api'
const MIN_DEPOSIT = 2000

async function createDeposit(amount) {
  const { data } = await axios.get(`${API}/v2/deposit/create`, {
    params: {
      amount,
      payment_id: 'qris'
    },
    headers: { 'x-apikey': global.api }
  })
  return data
}

async function checkDeposit(id) {
  const { data } = await axios.get(`${API}/v2/deposit/status`, {
    params: { id },
    headers: { 'x-apikey': global.api }
  })
  return data
}

let handler = async (m, { conn, args }) => {

  if (!global.api)
    return m.reply('API belum diset.')

  if (!args[0] || isNaN(args[0]))
    return m.reply('Contoh: .deposit 2000')

  let amount = parseInt(args[0])

  // 🔥 MINIMAL DEPOSIT 2K
  if (amount < MIN_DEPOSIT)
    return m.reply('❌ Minimal deposit Rp2.000')

  await m.reply('⏳ Membuat QRIS...')

  let res = await createDeposit(amount)

  if (!res.success)
    return m.reply('Gagal membuat deposit.')

  let d = res.data

  await conn.sendFile(
    m.chat,
    d.qr_image,
    'qris.png',
`╭───〔 *DEPOSIT QRIS* 〕
│ ID      : ${d.id}
│ Total   : Rp${d.total.toLocaleString()}
│ Minimal : Rp2.000
│ Aktif   : 5 menit
╰────────────────`,
    m
  )

  // AUTO CEK STATUS
  let interval = setInterval(async () => {

    let status = await checkDeposit(d.id)
    if (!status.success) return

    if (status.data.status === 'paid') {

      let user = db.data.users[m.sender] || (db.data.users[m.sender] = {})
      user.saldo = (user.saldo || 0) + status.data.diterima

      clearInterval(interval)

      await conn.sendMessage(m.chat, {
        text:
`✅ *DEPOSIT BERHASIL*

💰 Masuk : Rp${status.data.diterima.toLocaleString()}
💳 Saldo kamu : Rp${user.saldo.toLocaleString()}`
      })
    }

    if (status.data.status === 'expired') {
      clearInterval(interval)
      await conn.sendMessage(m.chat, {
        text: '❌ Deposit expired.'
      })
    }

  }, 10000)
}

handler.command = /^deposit$/i
handler.tags = ['nokos']
handler.help = ['deposit']

module.exports = handler